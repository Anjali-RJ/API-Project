package com.kiranacademy.APIex;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController

@CrossOrigin("http://localhost:8080")
public class StudentController {
	
	@Autowired
	SessionFactory factory;
	int age;
	
	public void setAge(int a)
	{
		age = a;
	}
	
	public StudentController() 
	{
		System.out.println("age is: "+ age + "factory is: "+factory);
		//Session session = factory.openSession();
	}
	
	@GetMapping("students")
	List<Student> allstudents()
	
	{
		Session session = factory.openSession();
		List<Student> al = session.createCriteria(Student.class).list();
		
		return al;
	}
	
	
	 @GetMapping("student/{rno}")
	 public Student getStudent(@PathVariable int rno) 
	  {
	  	Session session = factory.openSession();
	  	Student student=session.load(Student.class, rno);
	    return student;
	  }
	 
	
	@PostMapping("student")
	public List<Student> addStudent(@RequestBody Student student)
	{
		Session session = factory.openSession();
	  	
		Transaction tx = session.beginTransaction();
		
		session.save(student);
		tx.commit();
		
		List<Student> list = allstudents();
	  return list;
	}
	 
	@DeleteMapping("student/{rno}")
	public List<Student> deleteStudent(@PathVariable int rno)
	{
		Session session = factory.openSession();
		Student student = session.load(Student.class, rno);
        
		Transaction tx = session.beginTransaction();
		
		session.delete(student);
		tx.commit();
		
		List<Student> list = allstudents();
	  return list;
		 
		 
	}
	
	@PutMapping("student")
	public List<Student> updateStudent(@PathVariable Student clientStudent)
	{
		Session session = factory.openSession();
		
        
		Transaction tx = session.beginTransaction();
		
		session.saveOrUpdate(clientStudent);
		tx.commit();
		
		List<Student> list = allstudents();
	     return list;
	} 
}
	
	