package com.kiranacademy.APIex;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	//localhost:8080/apicall
	@RequestMapping("apicall")
	public String apicall()
	{
		return "apicall";
	}
	
	@RequestMapping("test3")
    public ModelAndView test3()
    {
		ArrayList<String> al=new ArrayList();
		al.add("JBK");
		al.add("javabykiran");
		al.add("Kiranacademy");
		
		ModelAndView modelAndView = new ModelAndView("test3", "data", al);
		return modelAndView;
		
    }
}
